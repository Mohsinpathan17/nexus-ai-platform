# Focus — NEXYRAL reference app

A real React + TypeScript task workspace: create tasks, set priority, complete, search, delete, save locally and export JSON. This is an interactive reference app, not a recorded autonomous AI build.

Requires Node.js 24 or later.

```sh
npm install
npm run dev
```

Production check:

```sh
npm run build
npm run preview
```

No API keys, accounts, backend, or payments are needed. Browser data is local to the origin/device and is not uploaded. Font licenses are included in public/fonts.
