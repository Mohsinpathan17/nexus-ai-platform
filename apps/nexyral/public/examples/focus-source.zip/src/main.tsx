import React from 'react';
import { createRoot } from 'react-dom/client';
import FocusWorkspace from './components/examples/FocusWorkspace';
import './styles/base.css';
import './styles/fonts.css';
import './styles/showcase.css';
createRoot(document.getElementById('root')!).render(<React.StrictMode><main><div className="example-heading"><span>FOCUS / BUILT FOR NEXYRAL</span><h1>A little space to focus.</h1><p>A working reference app. Your tasks stay on this device.</p></div><FocusWorkspace /></main></React.StrictMode>);
