import { useCallback, useEffect, useState, type ReactNode } from "react";
import type { Session } from "../../shared/contracts";
import { api } from "../lib/api";
import { AuthContext } from "./auth-context";
export default function AuthProvider({ children }: { children: ReactNode }) {
  const [session, setSession] = useState<Session>({
    user: null,
    csrfToken: null,
  });
  const [phase, setPhase] = useState<"loading" | "ready" | "unavailable">(
    import.meta.env.VITE_PUBLIC_DEMO === "1" ? "ready" : "loading",
  );
  const update = useCallback((next: Session) => {
    setSession(next);
    setPhase("ready");
  }, []);
  const refresh = useCallback(async () => {
    try {
      update(await api<Session>("/auth/session"));
    } catch {
      setPhase("unavailable");
    }
  }, [update]);
  useEffect(() => {
    if (import.meta.env.VITE_PUBLIC_DEMO === "1") {
      return;
    }
    const controller = new AbortController();
    void api<Session>("/auth/session", { signal: controller.signal })
      .then((next) => {
        if (!controller.signal.aborted) update(next);
      })
      .catch(() => {
        if (!controller.signal.aborted) setPhase("unavailable");
      });
    const expired = () => update({ user: null, csrfToken: null });
    window.addEventListener("nexyral:session-expired", expired);
    return () => {
      controller.abort();
      window.removeEventListener("nexyral:session-expired", expired);
    };
  }, [update]);
  async function logout() {
    await api("/auth/logout", {
      method: "POST",
      body: {},
      csrf: session.csrfToken,
    });
    update({ user: null, csrfToken: null });
  }
  return (
    <AuthContext.Provider
      value={{ ...session, phase, update, refresh, logout }}
    >
      {children}
    </AuthContext.Provider>
  );
}
